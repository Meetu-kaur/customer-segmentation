# Market_Segmentation
Market Segmentation using K Means Clustering in Python
